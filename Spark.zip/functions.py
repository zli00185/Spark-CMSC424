import json
import re
from statistics import mode
# A hack to avoid having to pass 'sc' around
dummyrdd = None
def setDefaultAnswer(rdd): 
    global dummyrdd
    dummyrdd = rdd

def task1(postsRDD):
    output = postsRDD.filter(lambda x: x['tags'] != None).map(lambda x: (x['id'], x['title'], x['tags'])).filter(lambda x: '<postgresql-9.4>' in x[2])
    return output

def task2(postsRDD):
    def foo(tuple): 
        result  =[]
        for t in tuple[1]:
            result.append((tuple[0], t))
        return result
    
    output = postsRDD.filter(lambda x: x['tags'] != None).map(lambda x : (x['id'], x['tags'][1:-1].split("><")))
    output = output.flatMap(foo)
    return output

def task3(postsRDD):
    def foo(tuple): 
        result  =[]
        for t in tuple[1]:
            result.append((tuple[0], t))
        return result

    
    def foo1(tuple):
        nodup = [*set(tuple[1])]
        nodup.sort()
    
        return (tuple[0], nodup[0:5])

    a = postsRDD.filter(lambda x: x['tags'] != None).map(lambda x : (x['creationdate'][:4], x['tags'][1:-1].split("><")))
    output = a.reduceByKey(lambda x, y: x+y).map(foo1).sortByKey()
    
    return output

def task4(usersRDD, postsRDD):
    user = usersRDD.map(lambda x: (x['id'],x['displayname']))
    post = postsRDD.map(lambda x : (x['owneruserid'], (x['id'],x['title'])))
    a1 = user.join(post)
    def foo3(tuple):
        result = []
        return (tuple[0], tuple[1][0],  tuple[1][1][0],tuple[1][1][1])

    output = a1.map(foo3)
    
    return output

def task5(postsRDD):
    
    def foo(tuple): 
        result  =[]
        for t in tuple[0]:
            for c in tuple[1]:
                result.append((t, c))
        return result
    

    a1 = postsRDD.filter(lambda x: x['tags'] != None).map(lambda x : (x['title'].split(' '), x['tags'][1:-1].split("><")))
    output = a1.map(foo).flatMap(lambda x: x).map(lambda x: ((x[0],x[1]), 1)).reduceByKey(lambda x, y:x+y).filter(lambda x: x[0][0]!= '').sortByKey()
    return output


def task6(amazonInputRDD):
    def foo(string):
        x = string.split(' ')
        return (x[0][4:], x[1][7:],x[2])
    
    output = amazonInputRDD.map(foo)
    return output

def task7(amazonInputRDD):
    
    def foo(input):
        x = input.split(' ')
        return (x[0][4:],int(x[1][7:]),float(x[2]))

    
    a = amazonInputRDD.map(foo)
    a1 = a.map(lambda x: ("user"+x[0], x[2])).reduceByKey(lambda x, y: x+y)
    a2 = a.map(lambda x: ("user"+x[0], 1)).reduceByKey(lambda x, y: x+y)
    a3 = a1.join(a2)
    output = a3.map(lambda x: (x[0],x[1][0]/x[1][1]))
    return output

def task8(amazonInputRDD):
    
    def foo(string):
        x = string.split(' ')
        return (x[1],float(x[2]))

    def foo1(tuple):
        x = tuple[1]
        x.sort(reverse=True)
        return (tuple[0], mode(x))
    
    output = amazonInputRDD.map(foo).groupByKey().map(lambda x : (x[0], list(x[1]))).map(foo1)
    
    return output

def task9(logsRDD):
    def foo(input):
        x = input.split(' ')
        year = x[3].split('/')
        return (year[2][:4],1)

    output = logsRDD.map(foo).reduceByKey(lambda x, y: x+y)
    
    return output

def task10_flatmap(line):
    regex = re.compile('[^a-zA-Z0-9 ]')
    x = regex.sub('', line)
    y = x.split(' ')
    return y

def task11(playRDD):
    
    def foo(input):
        y = input.split(' ')
        while('' in y):
            y.remove('')
        return (y[0], (input,len(y)))

    output = playRDD.map(foo).filter(lambda x: x[1][1]>10)
    
    return output

def task12(nobelRDD):
    def foo(tuple):
        cate = tuple['category']
        arr = tuple['laureates']
        result = []
        for t in arr:
            result.append(t['surname'])
        return (cate, result)

    def foo1(tuple):
        result =[]
        for t in tuple[1]:
            for y in t:
                result.append(y)
        return (tuple[0], result)


    output = nobelRDD.map(foo).groupByKey().map(lambda x : (x[0], list(x[1]))).map(foo1)
    
    return output

def task13(logsRDD, l):
    
  
    def foo(input):
        x = input.split(' ')
        year = x[3].split(':')
        return (x[0], year[0][1:])

    def foo1(input):
        x = [*set(input[1])]
        return (input[0],x)

    def check(input):
        arr = input[1]
        output = True
        for e in l:
            if e not in arr:
                output = False
        return output


    output = logsRDD.map(foo).groupByKey().map(lambda x : (x[0], list(x[1]))).map(foo1).map(lambda x:(x[0], x[1])).filter(check).sortByKey().map(lambda x: x[0])


    return output

def task14(logsRDD, day1, day2):
    def foo(input):
        x = input.split(' ')
        y = input.split('"')
        z = y[1].split(' ')
        year = x[3].split(':')
        return (x[0], z[1] ,year[0][1:])

    firstday = logsRDD.map(foo).filter(lambda x: x[2]==day1).map(lambda x:(x[0],x[1]))
    secondday = logsRDD.map(foo).filter(lambda x: x[2]==day2).map(lambda x:(x[0],x[1]))

    output = firstday.cogroup(secondday).sortByKey().map(lambda x: (x[0],(list(x[1][0]),list(x[1][1]))))
    output = output.filter(lambda x: len(x[1][0])!=0 and len(x[1][1])!=0)
    return output

def task15(bipartiteGraphRDD):
    output = bipartiteGraphRDD.map(lambda x: (x[0], 1)).reduceByKey(lambda x, y: x+y).map(lambda x: (x[1],1)).reduceByKey(lambda x, y: x+y).sortByKey()


    return output

def task16(nobelRDD):
    def foo(input):
        x = input['laureates']
        return x

    def foo1(input):
        a = input['motivation'].split()
        first = ''
        sentence = []
        for word in a:
            sentence.append((first, word))
            first = word
        sentence.remove(('', a[0]))
        return sentence
    

    output = nobelRDD.flatMap(foo).filter(lambda x: 'motivation' in x).flatMap(foo1)
    output = output.map(lambda x: ((x[0], x[1]),1)).reduceByKey(lambda x,y: x+y).sortByKey()
    return output
